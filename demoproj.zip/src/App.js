import React, { Component } from 'react';
import './App.css';
import ListComponent from './component/ListComponent.js';

class App extends Component {
	constructor(props) {
		super(props);
		this.state={
			deepCloneObjOutput:[],
			anagramsFirstStr:"",
			anagramsSecndStr:"",
			anagramsChk:false,
			secOutputshow:false,
			inputValue:"",
			listData:[]
		}
	}
	updateObj=(e)=>{
		let inputVal = e.target.value;
		console.log(e.target.value);
		this.setState({
			deepCloneObj:[inputVal]
		})
	}
	deepClone=(obj,e)=>{
		let deepCloneObjDup = Object.assign({}, obj)
		console.log(JSON.stringify(deepCloneObjDup));
		this.setState({
			deepCloneObjOutput:[JSON.stringify(deepCloneObjDup)]
		})
	}
	getanagramsValue=(strName,e)=>{
		this.setState({
			[strName]:e.target.value
		})
	}
	isAnagram=(str1, str2) => {
		const anagrams = str =>
								str
								.toLowerCase()
								.split('')
								.sort()
								.join('');
	  return anagrams(str1) === anagrams(str2);
	};
	checkAnagrams=()=>{
		const {anagramsFirstStr,anagramsSecndStr} = this.state;
		let anagramsFlag = true;
		
		if(anagramsFirstStr == ""){
			anagramsFlag = false;
		}
		if(anagramsSecndStr == ""){
			anagramsFlag = false;
		}
		const isAnagramChk =  this.isAnagram(anagramsFirstStr,anagramsSecndStr);
		if(!anagramsFlag){			
			alert("Please Enter");
		}
		this.setState({
			anagramsChk:isAnagramChk,
			secOutputshow:anagramsFlag
		})
	}
	inputChange=(e)=>{
		this.setState({
			inputValue:e.target.value
		})
	}
	getValue=()=>{
		let inputValue=this.state.inputValue
		let listData=this.state.listData
		if(inputValue != ""){
			listData.push(inputValue);
		}else{
			alert("Please enter a value");
		}
		this.setState({
			listData,
			inputValue:""
		})
	}
	render() {
		const {deepCloneObjOutput,anagramsFirstStr,anagramsSecndStr,anagramsChk,secOutputshow,inputValue,listData}=this.state;
		return (
			<div 
				style={{
					width:"500px",
					margin:"20px auto"
				}}
			>
				<div 
					style={{
						width:"100%",
						float:"left"
					}}
				>
					<span 
						style={{
							width:"auto",
							padding:"10px",
							background:"#cccccc",
							cursor:"pointer"
						}} 
						onClick={this.deepClone.bind(this,{ name: "Hitachi MGRM NET", address: { city: "Gurgaon", country: "India" } })}
					>
						deepClone Object
					</span>					
					<label 
						style={{
							width:"100%",
							float:"left",
							margin:"10px 0 10px 0"
						}}
					>
						1st Question Output
					</label>
					<div 
						style={{
							border:"1px solid #cccccc",
							width:"100%",
							margin:"10px 0 10px 0",
							float:"left",
							padding:"10px"
						}}
					>
						{this.state.deepCloneObjOutput}
					</div>
				</div>
				<div 
					style={{
						width:"100%",
						float:"left",
						marginTop:"30px"
					}}
				>
					<span 
						style={{
							width:"auto",
							padding:"10px",
							background:"#cccccc",
							cursor:"pointer",
							marginRight:"20px"
						}} 
						onClick={this.checkAnagrams}
					>
						Check anagrams
					</span>
					<input 
						type="text" 
						value={this.state.anagramsFirstStr} 
						onChange={this.getanagramsValue.bind(this,"anagramsFirstStr")} 
						style={{
							marginRight:"20px"
						}}
					/>
					<input 
						type="text" 
						value={this.state.anagramsSecndStr} 
						onChange={this.getanagramsValue.bind(this,"anagramsSecndStr")}
					/>
					<label 
						style={{
							width:"100%",
							float:"left",
							margin:"10px 0 10px 0"
						}}
					>
						2nd Question Output
					</label>
					<div 
						style={{
							border:"1px solid #cccccc",
							width:"100%",
							margin:"10px 0 10px 0",
							float:"left",
							padding:"10px"
						}}
					>
						{
							secOutputshow ?
								anagramsChk?
									<>
										Both string are Anagrams
									</>
								:
									<>
										Both string are not Anagrams
									</>
							:
								<></>
						}
					</div>
				</div>
				<div 
					style={{
						width:"100%",
						float:"left",
						marginTop:"30px"
					}}
				>
					<ListComponent 
						inputValue={inputValue} 
						inputChange={this.inputChange} 
						getValue={this.getValue} 
						listData={listData}
					/>
				</div>
			</div>
		);
	}
}

export default App;
