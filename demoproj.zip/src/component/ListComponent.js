import React, { Component } from 'react';
class ListComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
           
        }

    }
    


    render() {
		const {inputValue,inputChange,getValue,listData} = this.props;
        return (
            <div 
					style={{
						width:"100%",
						float:"left"
					}}
				>
					<input 
						type="text" 
						value={inputValue} 
						onChange={inputChange} 
						style={{
							marginRight:"20px"
						}}
					/>
					<span 
						style={{
							width:"auto",
							padding:"10px",
							background:"#cccccc",
							cursor:"pointer"
						}} 
						onClick={getValue}
					>
						ToDo
					</span>					
					<label 
						style={{
							width:"100%",
							float:"left",
							margin:"10px 0 10px 0"
						}}
					>
						3rd Question Output
					</label>
					<div 
						style={{
							border:"1px solid #cccccc",
							width:"100%",
							margin:"10px 0 10px 0",
							float:"left",
							padding:"10px"
						}}
					>
						{
							listData.map((item,i)=>{
								return(
									<div
										style={{
											width:"80%",
											float:"left",
											border:"1px solid #cccccc",
											padding:"5px",
										}}
										key={i}
									>
										{item}
									</div>
								)
							})
						}
					</div>
				</div>
        );
    }
}
export default ListComponent;
